/*
Name: 			Construction
Written by: 	Okler Themes - (http://www.okler.net)
Theme Version:	1.0.0
*/

(function( $ ) {

	'use strict';

}).apply( this, [ jQuery ]);